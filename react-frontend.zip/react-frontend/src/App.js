import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import ListEmployeeComponent from './components/ListEmployeeComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateEmployeeComponent from './components/CreateEmployeeComponent';
import UpdateEmployeeComponent from './components/UpdateEmployeeComponent';
import ViewEmployeeComponent from './components/ViewEmployeeComponent';
import getPSData from './services/EmployeeService'
import GetPSData from './GetPSData';
import SampleMap from './SimpleMap';
import xMap from './mapbox';
// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//        <h1>Hello World!</h1>
//       </header>
//     </div>
//   );
// }

function App() {
  return (
    <div>
     <GetPSData/>
     <div>
       <SampleMap/>
     </div>
     <div>
       <xMap/>
     </div>
    </div>
    
   
    
  );
}

export default App;
