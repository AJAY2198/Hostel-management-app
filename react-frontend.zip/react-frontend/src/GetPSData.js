
import axios from 'axios'
import React, { useState } from 'react';


export default function GetPSData() {
    const [count, setCount] = useState([]);
var psdata =()=>{
    try {
        axios

    .get("https://c9vietpit4.execute-api.us-east-2.amazonaws.com/getPSData/")
  
    .then(function (response){
        console.log(response.data)
        const json = response.data.body;

        const obj = JSON.parse(json);

    console.log("value", obj);
    setCount(obj);
    console.log(count);
    let finalarr = [];

    console.log(obj.length);

    for (let i = 0; i < obj.length; i++) {
      let elem = {
        latitude: obj[i].latitude,

        longitude: obj[i].longitude,
      };

      finalarr.push(elem);
    }

    console.log(finalarr);
    }) ;
    } catch (error) {
        console.log(error.message)
    }

};

    return (
        <div>
            <div>
            <button onClick={psdata}>data</button>
        </div>
                <header>

                    <nav className="navbar navbar-expand-md navbar-dark bg-dark">
                    
                        <div><a href="https://www.capgemini.com/" className= "navbar-brand">Employee Management App</a></div>    
                    </nav>   
                </header>  
                <div>
                    {count && count !== null ?
                count.map(ele => 
                    <div key = {ele.psid} >
                    <h1>
                        {ele.latitude}
                    </h1>
                    <h1>
                        {ele.longitude}
                    </h1>
                    <h1>
                        {ele.psname}
                    </h1>
                    </div>
                ):''   
                }
                </div>
            </div>
        
    )
}
